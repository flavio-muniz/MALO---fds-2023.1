from django.apps import AppConfig


class MaloAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Malo_App'
